package com.cdac.models;

public class StudentDTO extends Student {
	
	private int cid;

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}
	
	

}
